from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.index,name="index"),
    path('register/',views.register,name="register"),
    path('login/',views.login,name="login"),
    path('earning&wallet/all_earning/',views.all_earning,name="all_earning"),
    path('earning&wallet/wallets/',views.wallet,name="wallets"),
    path('new_registration',views.new_registration,name="new_registration"),
    path('geneology_report/',views.geneology_report,name="geneology_report"),
    path('all_downlist',views.all_downlist,name="all_downlist"),
    path('active_downlines/',views.active_downlines,name="active_downlines"),
]
