from django.contrib import admin
from .models import User_registration
# Register your models here.
admin.site.register(User_registration)