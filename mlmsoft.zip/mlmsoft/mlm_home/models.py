from django.db import models

# Create your models here.
class User_registration(models.Model):
    username = models.CharField(max_length=100,null=True)
    email = models.CharField(max_length=100,null=True)
    epin = models.CharField(max_length=8,null=True)
    paswd = models.CharField(max_length=100,null=True)
    chk = models.BooleanField(default=False)
    
    def __str__(self):
        return self.epin
       
class New_member_register(models.Model):
    sponserid = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    placementid = models.CharField(max_length=100)
    placementleg = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone = models.CharField(max_length=10)
    address = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    pincode = models.CharField(max_length=6)
    state = models.CharField(max_length=100)
    country = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    repassd =models.CharField(max_length=100)
    def __str__(self):
        return self.name  

