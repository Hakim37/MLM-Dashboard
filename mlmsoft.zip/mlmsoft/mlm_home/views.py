from django.shortcuts import render,redirect
from .models import User_registration
from django.contrib import messages
from .models import New_member_register
import random
import string
import uuid


def index(request):
    return render(request,'register.html')

def register(request):
    
    if request.method=="POST":
        username = request.POST['username']
        email = request.POST['email']                       
        epin = request.POST['epin']
        paswd = request.POST['paswd']
        chk = request.POST.get('chk')
        print(username)
        try:
            if User_registration.objects.filter(epin=epin).exists():
                print('epin--',epin)
                messages.success(request,'This e-pin is already exists')
                return render(request,'register.html')
            elif User_registration.objects.filter(email=email).exists():
                messages.success(request,'This Email is already exists')
                return render(request,'register.html', {"msg":"This Email is already exists"})
            else:
                print("kdfkjhdsfjdhjfhd")
                user = User_registration(username=username,email=email,epin=epin,paswd=paswd,chk=chk)
                print(user)
                user.save()
                messages.success(request,'User you have been registered successfully!')
                return redirect('login')    
        except Exception as e:
            print(e)
            # user = User_registration(username=username,email=email,epin=epin,password=password)
            # print(user)
            # user.save()
            # messages.success(request,'User you have been registered successfully!')
            return render(request,'register.html')
    else:
        return render(request,'register.html')

# def login(request):
#     if request.method =="POST":
#         m = User_registration.objects.filter(epin=request.POST['epin'])
#         try:
#             if m.password == request.POST['password']:
#                 request.session['epin'] = m.epin
#                 print('request---',request.session)
#                 messages.success(request,'User you have been successfully logged in!')
#                 return render(request,'dashboard.html')
#         except User_registration.DoesNotExist:
#             messages.error(request,'Invalid Credentials!!')
#             return render(request,'login.html')  
#     else:
#         return render(request,'login.html')

def login(request):
    if request.method =="POST":
        m = User_registration.objects.get(epin=request.POST['epin'])
        try:
            if m.paswd == request.POST['paswd']:
                print('request.session---',request.session)
                messages.success(request,'User have been successfully logged in!')
                return render(request,'register.html')
        except User_registration.DoesNotExist:
            messages.success(request,'invalid credentials!')
            return render(request,'login.html')

    return render(request,'login.html')

def index(request):
    return render(request,'index.html')

def all_earning(request):
    return render(request,'all_earning.html')

def wallet(request):
    return render(request,"wallets.html")

def new_registration(request):
    if request.method=="POST":
        sponserid = request.POST['sponserid']
        name = request.POST['name']
        placementid = request.POST['placementid']
        placementleg = request.POST['placementleg']
        email = request.POST['email']
        phone = request.POST['phone']
        address = request.POST['address']
        city = request.POST['city']
        pincode = request.POST['pincode']
        state= request.POST['state']
        country = request.POST['country']
        password = request.POST['password']
        repassd = request.POST['repassd']
        if New_member_register.objects.filter(password=request.POST.get('password')).exists():
            # n=New_member_register.objects.filter(password=request.POST.get('password')).exists()
            # print("n",n)
            messages.success(request,'password dosesnot match')
        elif New_member_register.objects.filter(email=request.POST.get('email')).exists():
            messages.success('request','email already exists')
            return render(request,'new_registration.html')
        else:
            user = New_member_register(sponserid=sponserid,name=name,placementid=placementid,placementleg=placementleg,email=email,phone=phone,address=
            address,city=city,pincode=pincode,state=state,country=country,password=password,repassd=repassd)
            user.save()
            messages.success(request,'user saved!')
            return redirect('/')

    return render(request,'new_registration.html')

def geneology_report(request):
    return render(request,'geneology_report.html')

def all_downlist(request):
    return render(request,'all_downlist.html')

def active_downlines(request):
    return render(request,'active_downlines.html')